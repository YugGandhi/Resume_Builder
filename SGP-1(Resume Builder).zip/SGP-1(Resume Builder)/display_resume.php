<?php
// Include database and functions classes
require_once 'database.class.php';
require_once 'function.class.php';

session_start();

// Assuming you have the user_id stored in the session after login
$user_id = $_GET['user_id'];
$template = $_GET['template']; // Get selected template

// Create an instance of the function and database classes
$func = new Functions();
$db = new Database();

// Fetch the user details from the database
$user_details = $func->getUserDetails($db, $user_id); // Assuming getUserDetails() fetches data by user_id

// Check if user details are found
if ($user_details) {
    // Populate the resume template with user data based on selected template
    if ($template == 'template1') {
        // Template 1
        include 'display_resume1.php'; // Include the template1 file
    } elseif ($template == 'template2') {
        // Template 2
        include 'display_resume2.php'; // Include the template2 file
    } elseif ($template == 'template3') {
        // Template 3
        include 'template3.php'; // Include the template3 file
    } elseif ($template == 'template4') {
        // Template 4
        include 'template4.php'; // Include the template4 file
    }
} else {
    echo "No user data found.";
}
?>
