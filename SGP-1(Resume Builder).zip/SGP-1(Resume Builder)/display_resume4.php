<?php
// Include necessary files for database connection and functions
include_once 'db_connection.php'; // Make sure you have your database connection set up here
include_once 'functions.class.php';

// Create an instance of the Functions class
$functions = new Functions();

// Start session to get user ID
session_start();
$user_id = $_SESSION['user_id']; // Get the logged-in user's ID

// Retrieve user details from the database
$user_details = $functions->getUserDetails($db, $user_id);

// Check if user details are retrieved
if ($user_details) {
    // Extract user data
    $name = $user_details['full_name'];
    $email = $user_details['email'];
    $phone = $user_details['phone'];
    $skills = $user_details['skills'];
    $education = $user_details['education'];
    $experience = $user_details['experience'];
    $projects = $user_details['projects'];
    $introduction = $user_details['introduction'];
} else {
    // Redirect to a default page if user details not found
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="display_resume4.css">
    <title>Resume Template 4</title>
</head>
<body>
    <div class="container">
        <div class="profile">
            <div class="profile-photo"></div>
            <div class="profile-info">
                <h2 class="heading heading-light">Profile</h2>
                <p class="profile-text"><?php echo $introduction; ?></p>
                <div class="contacts">
                    <div class="contacts-item">
                        <h3 class="contacts-title">
                            <i class="fas fa-phone-volume"></i> Phone
                        </h3>
                        <a href="tel:+<?php echo $phone; ?>" class="contacts-text"><?php echo $phone; ?></a>
                    </div>
                    <div class="contacts-item">
                        <h3 class="contacts-title">
                            <i class="fas fa-envelope"></i> Email
                        </h3>
                        <a href="mailto:<?php echo $email; ?>" class="contacts-text"><?php echo $email; ?></a>
                    </div>
                    <div class="contacts-item">
                        <h3 class="contacts-title">
                            <i class="fas fa-globe-americas"></i> Web
                        </h3>
                        <a href="http://www.example.com" class="contacts-text">www.example.com</a>
                    </div>
                    <div class="contacts-item">
                        <h3 class="contacts-title">
                            <i class="fas fa-map-marker-alt"></i> Home
                        </h3>
                        <address class="contacts-text">
                            24058, Belgium, Brussels, <br> Liutte 27, BE
                        </address>
                    </div>
                </div>
                <h2 class="heading heading-light">Languages</h2>
                <div class="languages">
                    <?php
                    // Assuming languages are stored as comma-separated values in the database
                    $languages = explode(",", $user_details['languages']);
                    foreach ($languages as $language) {
                        $language_details = explode(":", trim($language)); // Assuming the format is "Language: Proficiency"
                        echo '<div class="language">
                                <span class="language-text">' . $language_details[0] . '</span>
                                <strong class="languages-per">' . $language_details[1] . '</strong>
                              </div>';
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="resume">
            <div class="resume-wrap">
                <div class="logo">
                    <div class="logo-lines logo-lines_left">
                        <span class="logo-line"></span>
                        <span class="logo-line"></span>
                        <span class="logo-line"></span>
                    </div>
                    <div class="logo-img">
                        R/S
                    </div>
                    <div class="logo-lines logo-lines_right">
                        <span class="logo-line"></span>
                        <span class="logo-line"></span>
                        <span class="logo-line"></span>
                    </div>
                </div>

                <div class="about">
                    <h1 class="name"><?php echo $name; ?></h1>
                    <span class="position"><?php echo $introduction; ?></span>
                    <address class="about-address"><?php echo $user_details['address']; ?></address>
                    <div class="about-contacts">  
                        <a class="about-contacts__link" href="tel:+<?php echo $phone; ?>">
                            <b>t</b>: <?php echo $phone; ?></a> |
                        <a class="about-contacts__link" href="mailto:<?php echo $email; ?>">
                            <b>e</b>: <?php echo $email; ?> </a> |
                        <a class="about-contacts__link" href="http://www.example.com">
                            <b>w</b>: www.example.com</a>
                    </div>
                </div>

                <div class="experience">
                    <h2 class="heading heading_dark">Experience</h2>
                    <ul class="list">
                        <?php
                        // Assuming experience is stored as comma-separated values in the database
                        $experience_list = explode(",", $experience);
                        foreach ($experience_list as $exp) {
                            echo '<li class="list-item">
                                    <h4 class="list-item__title">' . trim($exp) . '</h4>
                                    <span class="list-item__date">Date</span>
                                    <p class="list-item__text">Description of the experience.</p>
                                  </li>';
                        }
                        ?>
                    </ul>
                </div>

                <div class="education">
                    <h2 class="heading heading_dark">Education</h2>
                    <ul class="list">
                        <?php
                        // Assuming education is stored as comma-separated values in the database
                        $education_list = explode(",", $education);
                        foreach ($education_list as $edu) {
                            echo '<li class="list-item list-item_non-border">
                                    <h4 class="list-item__title">' . trim($edu) . '</h4>
                                    <span class="list-item__date">Date</span>
                                    <p class="list-item__text">Description of the education.</p>
                                  </li>';
                        }
                        ?>
                    </ul>
                </div>

                <div class="skills">
                    <h2 class="heading heading_dark heading_skills">Skills</h2>
                    <ul class="skills-list">
                        <?php
                        // Assuming skills are stored as comma-separated values in the database
                        $skills_list = explode(",", $skills);
                        foreach ($skills_list as $skill) {
                            echo '<li class="skills-list__item">
                                    ' . trim($skill) . '
                                    <div class="level level-80"></div>
                                  </li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
