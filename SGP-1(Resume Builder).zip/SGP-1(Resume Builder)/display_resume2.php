<?php
// Include database and function files
require_once 'database.class.php';
require_once 'function.class.php';

// Start the session and retrieve user ID
session_start();
$user_id = $_SESSION['user_id'];

// Create instances of the function and database classes
$func = new Functions();
$db = new Database();

// Fetch user details from the database
$userData = $func->getUserDetails($db, $user_id);

if (!$userData) {
    echo "No user data found.";
    exit();
}

// Assign variables from the database record
$fullName = htmlspecialchars($userData['full_name']);
$email = htmlspecialchars($userData['email']);
$phone = htmlspecialchars($userData['phone']);
$skills = htmlspecialchars($userData['skills']);
$education = htmlspecialchars($userData['education']);
$experience = htmlspecialchars($userData['experience']);
$interests = htmlspecialchars($userData['interests']);
$projects = htmlspecialchars($userData['projects']);
$introduction = htmlspecialchars($userData['introduction']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resume of <?php echo $fullName; ?></title>
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic|Open+Sans:300,400,500,700|Waiting+for+the+Sunrise|Shadows+Into+Light" rel="stylesheet">
    <link rel="stylesheet" href="display_resume2.css">
</head>
<body>
    <div class="wrapper clearfix">
        <div class="left">
            <div class="name-hero">
                <div class="me-img"></div>
                <div class="name-text">
                    <h1><?php echo $fullName; ?></h1>
                    <p><?php echo $introduction; ?></p>
                    <p><?php echo $email; ?></p>
                    <p><?php echo $phone; ?></p>
                </div>
            </div>
        </div>
        <div class="right">
            <div class="inner">
                <section>
                    <h1>Employment</h1>
                    <p><?php echo nl2br($experience); ?></p>
                </section>
                <section>
                    <h1>Technical Skills</h1>
                    <ul class="skill-set">
                        <?php
                        $skillsArray = explode(",", $skills);
                        foreach ($skillsArray as $skill) {
                            echo "<li>" . trim(htmlspecialchars($skill)) . "</li>";
                        }
                        ?>
                    </ul>
                </section>
                <section>
                    <h1>Projects</h1>
                    <p><?php echo nl2br($projects); ?></p>
                </section>
                <section>
                    <h1>Education</h1>
                    <p><?php echo nl2br($education); ?></p>
                </section>
                <section>
                    <h1>Personal Interests</h1>
                    <ul class="skill-set">
                        <?php
                        $interestsArray = explode(",", $interests);
                        foreach ($interestsArray as $interest) {
                            echo "<li>" . trim(htmlspecialchars($interest)) . "</li>";
                        }
                        ?>
                    </ul>
                </section>
                <section>
                    <div class="handmade">
                        <p>handmade by <em><?php echo $fullName; ?></em></p>
                    </div>
                </section>
            </div>
        </div>
    </div>
</body>
</html>
