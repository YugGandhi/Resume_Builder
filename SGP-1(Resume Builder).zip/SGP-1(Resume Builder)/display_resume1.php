<?php
// Include necessary files for database connection and functions
include_once 'db_connection.php'; // Make sure you have your database connection set up here
include_once 'functions.class.php';

// Create an instance of the Functions class
$functions = new Functions();

// Start session to get user ID
session_start();
$user_id = $_SESSION['user_id']; // Get the logged-in user's ID

// Retrieve user details from the database
$user_details = $functions->getUserDetails($db, $user_id);

// Check if user details are retrieved
if ($user_details) {
    // Extract user data and fall back to default values if empty
    $name = !empty($user_details['full_name']) ? $user_details['full_name'] : 'Anthony Adamski';
    $email = !empty($user_details['email']) ? $user_details['email'] : 'adamskianthony@gmail.com';
    $phone = !empty($user_details['phone']) ? $user_details['phone'] : '(956) 500-5558';
    $skills = !empty($user_details['skills']) ? $user_details['skills'] : 'Java, PHP, JavaScript';
    $education = !empty($user_details['education']) ? $user_details['education'] : 'BS in Computer Science';
    $experience = !empty($user_details['experience']) ? $user_details['experience'] : '3+ years in mobile development';
    $interests = !empty($user_details['interests']) ? $user_details['interests'] : 'Tech, Music, Photography';
    $projects = !empty($user_details['projects']) ? $user_details['projects'] : 'Project1, Project2, Project3';
    $introduction = !empty($user_details['introduction']) ? $user_details['introduction'] : 'Mobile App Developer';
} else {
    // Redirect to a default page if user details not found
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="display_resume1.css">
    <title>Resume Template 1</title>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="full-name">
                <span class="first-name"><?php echo explode(" ", $name)[0]; ?></span>
                <span class="last-name"><?php echo explode(" ", $name)[1]; ?></span>
            </div>
            <div class="contact-info">
                <span class="email">Email: </span>
                <span class="email-val"><?php echo $email; ?></span>
                <span class="separator"></span>
                <span class="phone">Phone: </span>
                <span class="phone-val"><?php echo $phone; ?></span>
            </div>

            <div class="about">
                <span class="position">Position: <?php echo $introduction; ?></span>
                <span class="desc"><?php echo $introduction; ?></span>
            </div>
        </div>

        <div class="details">
            <div class="section">
                <div class="section__title">Experience</div>
                <div class="section__list">
                    <?php
                    // Assuming the experience is stored in a comma-separated format in the database
                    $experience_list = explode(",", $experience);
                    foreach ($experience_list as $exp) {
                        echo '<div class="section__list-item">';
                        echo '<div class="left">';
                        echo '<div class="name">' . trim($exp) . '</div>';
                        echo '</div>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>

            <div class="section">
                <div class="section__title">Education</div>
                <div class="section__list">
                    <?php
                    // Assuming education is stored similarly to experience in the database
                    $education_list = explode(",", $education);
                    foreach ($education_list as $edu) {
                        echo '<div class="section__list-item">';
                        echo '<div class="left">';
                        echo '<div class="name">' . trim($edu) . '</div>';
                        echo '</div>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>

            <div class="section">
                <div class="section__title">Projects</div>
                <div class="section__list">
                    <?php
                    // Assuming projects are stored in a comma-separated format
                    $projects_list = explode(",", $projects);
                    foreach ($projects_list as $project) {
                        echo '<div class="section__list-item">';
                        echo '<div class="name">' . trim($project) . '</div>';
                        echo '<div class="text">' . $introduction . '</div>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>

            <div class="section">
                <div class="section__title">Skills</div>
                <div class="skills">
                    <?php
                    // Assuming skills are stored in a comma-separated format
                    $skills_list = explode(",", $skills);
                    foreach ($skills_list as $skill) {
                        echo '<div class="skills__item">';
                        echo '<div class="left"><div class="name">' . trim($skill) . '</div></div>';
                        echo '<div class="right">';
                        echo '<input id="ck1" type="checkbox" checked />'; // Assuming all skills are checked
                        echo '<label for="ck1"></label>';
                        echo '</div>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>

            <div class="section">
                <div class="section__title">Interests</div>
                <div class="section__list">
                    <div class="section__list-item">
                        <?php echo $interests; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
