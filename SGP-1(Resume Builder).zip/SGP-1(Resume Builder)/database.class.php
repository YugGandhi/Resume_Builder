<?php

class Database
{
     private $host = 'localhost';
     private $username = 'root';
     private $database ='resumebulider';
     private $password = '';
     private $db = null;

     public function __construct(){
         $this->db = new mysqli($this->host,$this->username,$this->password,$this->database);
     }

     public function connect(){
        return $this->db;
     }
}

$db = new Database();
$db = $db->connect();