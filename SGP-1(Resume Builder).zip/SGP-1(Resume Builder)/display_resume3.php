<?php
// Include database and function files
require_once 'database.class.php';
require_once 'function.class.php';

// Start the session and retrieve user ID
session_start();
$user_id = $_SESSION['user_id'];

// Create instances of the function and database classes
$func = new Functions();
$db = new Database();

// Fetch user details from the database
$userData = $func->getUserDetails($db, $user_id);

if (!$userData) {
    echo "No user data found.";
    exit();
}

// Assign variables from the database record, fallback to static value if empty
$fullName = !empty($userData['full_name']) ? htmlspecialchars($userData['full_name']) : 'Anthony Adamski';
$occupation = !empty($userData['occupation']) ? htmlspecialchars($userData['occupation']) : 'Mobile App Developer';
$email = !empty($userData['email']) ? htmlspecialchars($userData['email']) : 'adamskianthony@gmail.com';
$phone = !empty($userData['phone']) ? htmlspecialchars($userData['phone']) : '(956) 500-5558';
$address = !empty($userData['address']) ? htmlspecialchars($userData['address']) : '10 Iroquois St Boston, MA 02120';
$profileDescription = !empty($userData['profile_description']) ? htmlspecialchars($userData['profile_description']) : 'Experienced Mobile App Developer with a passion for creating innovative mobile applications.';
$philosophy = !empty($userData['philosophy']) ? htmlspecialchars($userData['philosophy']) : 'Innovation is the key to progress.';
$interests = !empty($userData['interests']) ? htmlspecialchars($userData['interests']) : 'Tech, Music, Photography';
$socialLinks = [
    'facebook' => !empty($userData['facebook']) ? htmlspecialchars($userData['facebook']) : '#',
    'twitter' => !empty($userData['twitter']) ? htmlspecialchars($userData['twitter']) : '#',
    'linkedin' => !empty($userData['linkedin']) ? htmlspecialchars($userData['linkedin']) : '#'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resume of <?php echo $fullName; ?></title>
    <link href="https://fonts.googleapis.com/css?family=Lato:300,300italic,400,400italic" rel="stylesheet">
    <link rel="stylesheet" href="display_resume3.css">
</head>
<body>
    <!-- MAIN CONTAINER -->
    <div id="main_container">
        <!-- HEADER -->
        <div id="header">
            <!-- LOGOTYPE/NAME -->
            <div class="header_logotype_container">
                <h1 class="logotype_name"><?php echo $fullName; ?> <span class="purple"><?php echo $occupation; ?></span></h1>
                <h2 class="logotype_occupation"><?php echo $occupation; ?></h2>
            </div>
            <!-- MAIN MENU -->
            <div class="header_menu_container">
                <ul class="download_print_buttons horizontal_list">
                    <li><a href="#"><span class="icon entypo-download"></span>Download CV</a></li>
                    <li><a href="#"><span class="icon entypo-print"></span>Print CV</a></li>
                </ul>
                <div class="clear"></div>
                <ul class="header_menu horizontal_list">
                    <li><a class="no_border purple" href="#">Profile</a></li>
                    <li><a href="#">Education</a></li>
                    <li><a href="#">Skills</a></li>
                    <li><a href="#">Work Experience</a></li>
                    <li><a href="#">Featured Projects</a></li>
                    <li><a href="#">Awards</a></li>
                </ul>
            </div>
        </div>

        <!-- LEFT COL -->
        <div id="left_col">
            <div class="profile_frame">
                <div class="profile_picture"></div>
                <!-- Profile picture can be fetched from the database if available -->
            </div>
            <div class="hello_content">
                <h2>Hello!</h2>
                <p><?php echo $profileDescription; ?></p>
            </div>
            <div class="contact_details_content">
                <h2>Contact details</h2>
                <p class="purple">Phone:</p>
                <p><?php echo $phone; ?></p>
                <p class="purple">Email:</p>
                <p><?php echo $email; ?></p>
                <p class="purple">Address:</p>
                <p><?php echo $address; ?></p>
            </div>
            <a href="mailto:<?php echo $email; ?>" class="send_message_button">
                <span class="cut1"></span>
                <span class="cut2"></span>
                <span class="content">Send me a message <span class="fontawesome-double-angle-right"></span></span>
            </a>
            <div class="get_social_content">
                <h2>Get social</h2>
                <ul class="social_icons horizontal_list">
                    <li><a class="facebook" href="<?php echo $socialLinks['facebook']; ?>"><span class="entypo-facebook-circled"></span><span class="invisible">Facebook</span></a></li>
                    <li><a class="twitter" href="<?php echo $socialLinks['twitter']; ?>"><span class="entypo-twitter-circled"></span><span class="invisible">Twitter</span></a></li>
                    <li><a class="linkedin" href="<?php echo $socialLinks['linkedin']; ?>"><span class="entypo-linkedin-circled"></span><span class="invisible">LinkedIn</span></a></li>
                </ul>
            </div>
        </div>

        <!-- PROFILE CONTENT -->
        <div id="content_container">
            <div class="block">
                <h1>Profile</h1>
                <blockquote class="profile_quote">
                    <p>"There is no end to education. It is not that you read a book, pass an examination, and finish with education. The whole of life, from the moment you are born to the moment you die, is a process of learning."</p>
                    <p>Jiddu Krishnamurti.</p>
                    <span class="entypo-quote"></span>
                </blockquote>
            </div>
            <div class="block">
                <h2>A few words about me</h2>
                <p><?php echo $profileDescription; ?></p>
            </div>

            <div class="horizontal_line">
                <div class="line_left"></div>
                <div class="left_circle"></div>
                <div class="central_circle"></div>
                <div class="right_circle"></div>
                <div class="line_right"></div>
            </div>

            <div class="block">
                <h2>Philosophy</h2>
                <p><?php echo $philosophy; ?></p>
            </div>

            <div class="horizontal_line">
                <div class="line_left"></div>
                <div class="left_circle"></div>
                <div class="central_circle"></div>
                <div class="right_circle"></div>
                <div class="line_right"></div>
            </div>

            <div class="last block">
                <h2>Interests & Hobbies</h2>
                <p>I'm passionate about technology and human behavior, both determine almost all my interests and hobbies:</p>
                <ul>
                    <?php
                    $interestsArray = explode(",", $interests);
                    foreach ($interestsArray as $interest) {
                        echo "<li>" . trim(htmlspecialchars($interest)) . "</li>";
                    }
                    ?>
                </ul>
            </div>
        </div>

        <div class="clear"></div>

        <!-- FOOTER -->
        <div id="footer">
            <p class="footer_name"><?php echo $fullName; ?> CV 2015</p>
        </div>
    </div>
</body>
</html>
