<?php
// Include database and functions classes
require_once 'database.class.php';
require_once 'function.class.php';

// Start session to handle login
session_start();

// Create an instance of the function class
$func = new Functions();
$db = new Database();

// Check if the sign-up form was submitted
if (isset($_POST['sign_up'])) {
    $full_name = $_POST['full_name'];
    $email = $_POST['email_id'];
    $password = $_POST['password'];

    // Validate inputs (basic validation, can be expanded)
    if (empty($full_name) || empty($email) || empty($password)) {
        echo "Please fill in all fields.";
    } else {
        // Check if the full name or email already exists
        if ($func->userExists($db, $full_name, $email)) {
            echo "Full Name or email already taken.";
        } else {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            // Create the new user
            if ($func->createUser($db, $full_name, $email, $hashed_password)) {
                $_SESSION['message'] = "Registration successful!";
                header('Location: Login.php'); // Redirect to your HTML page
                exit();
            } else {
                echo "Error during registration. Please try again.";
            }
        }
    }
}

// Check if the sign-in form was submitted
if (isset($_POST['sign_in'])) {
    $full_name = $_POST['full_name'];
    $password = $_POST['password'];

    // Validate inputs (basic validation, can be expanded)
    if (empty($full_name) || empty($password)) {
        echo "Please fill in all fields.";
    } else {
        // Retrieve user data from the database using full_name
        $user = $func->getUserByUsername($db, $full_name); // Adjusted to use getUserByUsername()
        if ($user && password_verify($password, $user['password'])) {
            // Set session variables for login
            $_SESSION['user_id'] = $user['id']; // Store user_id in session for later use
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['message'] = "Login successful!";
            header('Location: templetes/templete.html'); // Redirect to your HTML page
            exit();
        } else {
            echo "Invalid Full Name or password.";
        }
    }
}
?>
