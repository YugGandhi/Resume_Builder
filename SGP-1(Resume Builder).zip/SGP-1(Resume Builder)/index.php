<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Builder | Home</title>
    <link rel="icon" href="./logo.png">
    <style>
        /* body {
            font-family: 'Poppins', Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #f3f4f6;
            color: #333;
        }

        .container {
            text-align: center;
            width: 85%;
            margin: 0 auto;
        }

        nav {
            background: linear-gradient(to bottom, #5a9bd5, #6ab0e6);
            border-radius: 8px;
            color: #fff;
            padding: 1rem 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }

        nav:hover {
            background: linear-gradient(to bottom, #6ab0e6, #79c4f0);
        }

        nav .nav-links {
            list-style: none;
            display: flex;
            justify-content: space-around;
            align-items: center;
        }

        nav .nav-links li {
            margin: 0 1rem;
            position: relative;  
        }

        nav .nav-links a {
            color: #fff;
            text-decoration: none;
            padding: 0.5rem 1rem;
            transition: color 0.3s ease, background-color 0.3s ease;
        }

        nav .nav-links a:hover {
            color: #5a9bd5;
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 5px;
        }

        nav .btn {
            color: #fff;
            padding: 0.7rem 1.5rem;
            border-radius: 25px;
            background-color: #f4a261;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        nav .btn:hover {
            background-color: #e76f51;
            transform: translateY(-3px);
        }

        .profile-menu {
            position: relative;
            display: inline-block;
        }

        .dropdown {
            display: none;
            position: absolute;
            background-color: rgb(0, 0, 0);
            min-width: 160px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            border-radius: 5px;
        }

        .dropdown a {
            color: #333;
            padding: 10px 16px;
            text-decoration: none;
            display: block;
            text-align: left;
        }

        .dropdown a:hover {
            background-color: #f4a261;
            color: white;
        }

        .profile-menu:hover .dropdown {
            display: block;
            color: #6ab0e6;
        }

        .hero {
            background: url('hero-background.jpg') no-repeat center center/cover;
            color: #fff;
            text-align: center;
            height: 400px;
            padding: 6rem 0;
            animation: slider 5s infinite ease-in;
        }

        @keyframes slider {
            0% { background-image: url('pic-1.jpg'); }
            35% { background-image: url('pic-2.jpg'); }
            75% { background-image: url('pic-3.jpg'); }
            100% { background-image: url('pic-1.jpg'); }
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            animation: fadeIn 2s ease;
        }

        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        .hero p {
            font-size: 1.5rem;
            margin-bottom: 2rem;
            animation: fadeIn 2s ease;
        }

        .hero .btn {
            background: #f4a261;
            color: #fff;
            padding: 1rem 2.5rem;
            border-radius: 30px;
            text-decoration: none;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .hero .btn:hover {
            background-color: #e76f51;
            transform: translateY(-3px);
        }

        .features, .faq, .resources {
            padding: 3rem 0;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 2rem 0;
        }

        .testimonial-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
        }

        .testimonial {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 1rem;
            flex: 1 1 300px;
        }

        .pricing {
            padding: 3rem 0;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
        }

        .pricing .btn {
            background: #f4a261;
            color: #fff;
            padding: 1rem 2.5rem;
            border-radius: 30px;
            text-decoration: none;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .pricing .btn:hover {
            background-color: #e76f51;
            transform: translateY(-3px);
        }

        .contact {
            background-color: #ffdb2b;
            color: #0e171f;
            padding: 3rem 0;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1.5rem 0;
            border-radius: 8px;
            animation: fadeIn 2s ease;
        }

        .faq-item {
            margin: 1rem 0;
        }

        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2.5rem;
            }

            .hero p {
                font-size: 1.2rem;
            }
        } 
    */
        
        body {

        font-family: 'Poppins', Arial, sans-serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background-color: #f3f4f6;
        color: #333;
        }

        .container {
        text-align: center;
        width: 85%;
        margin: 0 auto;
        }

        nav {
        background: linear-gradient(to bottom, #5a9bd5, #6ab0e6);
        border-radius: 8px;
        color: #fff;
        padding: 1rem 0;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        position: fixed;
        width: 100%;
        top: 0;
        z-index: 1000;
        transition: background-color 0.3s ease;
        }

        nav:hover {
        background: linear-gradient(to bottom, #6ab0e6, #79c4f0);
        }

        nav .nav-links {
        list-style: none;
        display: flex;
        justify-content: space-around;
        align-items: center;
        }

        nav .nav-links li {
        margin: 0 1rem;
        position: relative; /* Needed for dropdown positioning */
        }

        nav .nav-links a {
        color: #fff;
        text-decoration: none;
        padding: 0.5rem 1rem;
        transition: color 0.3s ease, background-color 0.3s ease;
        }

        nav .nav-links a:hover {
        color: #5a9bd5;
        background-color: rgba(255, 255, 255, 0.2);
        border-radius: 5px;
        }

        nav .btn {
        color: #fff;
        padding: 0.7rem 1.5rem;
        border-radius: 25px;
        background-color: #f4a261;
        transition: background-color 0.3s ease, transform 0.3s ease;
        }

        nav .btn:hover {
        background-color: #e76f51;
        transform: translateY(-3px);
        }

        .profile-menu {
        position: relative;
        display: inline-block;
        }

        .dropdown {
        display: none;
        position: absolute;
        background-color: rgb(0, 0, 0);
        min-width: 160px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        z-index: 1000;
        border-radius: 5px;
        }

        .dropdown a {
        color: #333;
        padding: 10px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
        }

        .dropdown a:hover {
        background-color: #f4a261;
        color: white;
        }

        .profile-menu:hover .dropdown {
        display: block;
        color: #6ab0e6;
        }

        .hero {
        background: url('hero-background.jpg') no-repeat center center/cover;
        color: #fff;
        text-align: center;
        height: 400px;
        padding: 6rem 0;
        animation: slider 5s infinite ease-in;
        }

        @keyframes slider {
        0% { background-image: url('pic-1.jpg'); }
        35% { background-image: url('pic-2.jpg'); }
        75% { background-image: url('pic-3.jpg'); }
        100% { background-image: url('pic-1.jpg'); }
        }

        .hero h1 {
        font-size: 3rem;
        margin-bottom: 1rem;
        animation: fadeIn 2s ease;
        }

        @keyframes fadeIn {
        0% { opacity: 0; }
        100% { opacity: 1; }
        }

        .hero p {
        font-size: 1.5rem;
        margin-bottom: 2rem;
        animation: fadeIn 2s ease;
        }

        .hero .btn {
        background: #f4a261;
        color: #fff;
        padding: 1rem 2.5rem;
        border-radius: 30px;
        text-decoration: none;
        transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .hero .btn:hover {
        background-color: #e76f51;
        transform: translateY(-3px);
        }

        .features, .faq, .resources {
        padding: 3rem 0;
        text-align: center;
        background-color: rgba(255, 255, 255, 0.95);
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin: 2rem 0;
        }

        .testimonial-list {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        }

        .testimonial {
        background-color: rgba(255, 255, 255, 0.9);
        padding: 2rem;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin: 1rem;
        flex: 1 1 300px;
        }

        .pricing {
        padding: 3rem 0;
        text-align: center;
        background-color: rgba(255, 255, 255, 0.95);
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin-bottom: 2rem;
        }

        .pricing .btn {
        background: #f4a261;
        color: #fff;
        padding: 1rem 2.5rem;
        border-radius: 30px;
        text-decoration: none;
        transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .pricing .btn:hover {
        background-color: #e76f51;
        transform: translateY(-3px);
        }

        .contact {
        background-color: #ffdb2b;
        color: #0e171f;
        padding: 3rem 0;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        footer {
        background-color: #333;
        color: #fff;
        text-align: center;
        padding: 1.5rem 0;
        border-radius: 8px;
        animation: fadeIn 2s ease;
        }

        .faq-item {
        margin: 1rem 0;
        }

        @media (max-width: 768px) {
        .hero h1 {
            font-size: 2.5rem;
        }

        .hero p {
            font-size: 1.2rem;
        }
        }
        .templates {
        padding: 3rem 0;
        text-align: center;
        background-color: rgba(255, 255, 255, 0.95);
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin: 2rem 0;
        }

        .template-slider {
        display: flex;
        justify-content: center;
        gap: 1.5rem;
        flex-wrap: wrap;
        }

        .template-card {
        cursor: pointer;
        background-color: rgba(255, 255, 255, 0.9);
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        width: 200px;
        text-align: center;
        transition: transform 0.3s ease;
        }

        .template-card:hover {
        transform: scale(1.05);
        }

        .template-card img {
        width: 100%;
        height: auto;
        border-radius: 8px;
        }
        .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 20px;
        border-radius: 10px;
        width: 300px;
        text-align: center;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .modal-content a {
        display: inline-block;
        margin: 1rem;
        color: #fff;
        padding: 0.7rem 1.5rem;
        border-radius: 25px;
        text-decoration: none;
        }

        .modal-content a.login-btn {
        background-color: #5a9bd5;
        }

        .modal-content a.signup-btn {
        background-color: #f4a261;
        }

        .modal-content a:hover {
        opacity: 0.8;
        }

        .close-btn {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
        }

        .close-btn:hover,
        .close-btn:focus {
        color: #000;
        text-decoration: none;
        cursor: pointer;
}
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <div class="container">
            <ul class="nav-links">
                <li><a href="#features">Features</a></li>
                <li><a href="#testimonials">Testimonials</a></li>
                <li><a href="#pricing">Templates</a></li>
                <li><a href="#faq">FAQ</a></li>
                <li><a href="#resources">Resources</a></li>
                <li class="profile-menu">
                    <a href="#" class="btn">Profile</a>
                    <div class="dropdown">
                        <a href="Login.php">Login</a>
                        <a href="Login.php">Signup</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Hero Section -->
    <header class="hero" role="banner">
        <div class="container">
            <h1>Create Your Professional Resume in Minutes</h1>
            <p>Easy to use, customizable templates that help you stand out.</p>
            <a href="#features" class="btn">Get Started</a>
        </div>
    </header>
    <section id="templates" class="templates" role="region" aria-labelledby="templates-title">
        <div class="container">
            <h2 id="templates-title">Choose Your Template</h2>
            <div class="template-slider">
                <div class="template-card" onclick="showLoginPopup()">
                    <img src="template-1.png" alt="Template 1">
                    <p>Modern Template</p>
                </div>
                <div class="template-card" onclick="showLoginPopup()">
                    <img src="template-3.png" alt="Template 2">
                    <p>Professional Template</p>
                </div>
                <div class="template-card" onclick="showLoginPopup()">
                    <img src="template-4.png" alt="Template 3">
                    <p>Classic Template</p>
                </div>
            </div>
        </div>
    </section>
    <!-- Features Section -->
    <section id="features" class="features" role="region" aria-labelledby="features-title">
        <div class="container">
            <h2 id="features-title">Features</h2>
            <div class="feature-list">
                <div class="feature">
                    <h3>Easy to Use</h3>
                    <p>Our intuitive interface makes it easy for anyone to create a resume.</p>
                </div>
                <div class="feature">
                    <h3>Customizable Templates</h3>
                    <p>Choose from a variety of templates to match your style.</p>
                </div>
                <div class="feature">
                    <h3>Download in Multiple Formats</h3>
                    <p>Download your resume in PDF, Word, or plain text.</p>
                </div>
                <div class="feature">
                    <h3>Real-Time Preview</h3>
                    <p>See a live preview of your resume as you build it.</p>
                </div>
                <div class="feature">
                    <h3>User Account Benefits</h3>
                    <p>Save and edit your resumes anytime with a registered account.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section id="testimonials" class="testimonials" role="region" aria-labelledby="testimonials-title">
        <div class="container">
            <h2 id="testimonials-title">What Our Users Say</h2>
            <div class="testimonial-list">
                <div class="testimonial">
                    <p>"This tool made it so easy to create a professional resume. Highly recommend!"</p>
                    <h4>John Doe</h4>
                </div>
                <div class="testimonial">
                    <p>"I landed my dream job thanks to this amazing resume builder."</p>
                    <h4>Jane Smith</h4>
                </div>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section id="pricing" class="pricing" role="region" aria-labelledby="pricing-title">
        <div class="container">
            <h2 id="pricing-title">Get Started</h2>
            <a href="register.php" class="btn">Create Your Resume!</a>
        </div>
    </section>

    <!-- FAQ Section -->
    <section id="faq" class="faq" role="region" aria-labelledby="faq-title">
        <div class="container">
            <h2 id="faq-title">Frequently Asked Questions</h2>
            <div class="faq-item">
                <h3>How do I create my resume?</h3>
                <p>Simply select a template, fill in your details, and download your resume!</p>
            </div>
            <div class="faq-item">
                <h3>Can I edit my resume after saving?</h3>
                <p>Yes, registered users can save and edit their resumes anytime.</p>
            </div>
        </div>
    </section>

    <!-- Resources Section -->
    <section id="resources" class="resources" role="region" aria-labelledby="resources-title">
        <div class="container">
            <h2 id="resources-title">Resume Writing Resources</h2>
            <p>Check out our blog for tips on crafting the perfect resume.</p>
            <p>Coming Soon!</p>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact" role="region" aria-labelledby="contact-title">
        <div class="container">
            <h2 id="contact-title">Contact Us</h2>
            <a href="https://www.instagram.com/your-profile" target="_blank" aria-label="Instagram Profile"><img src="instagram-icon.png" alt="Instagram"></a>
            <a href="https://www.linkedin.com/in/your-profile" target="_blank" aria-label="LinkedIn Profile"><img src="linkedin-icon.png" alt="LinkedIn"></a>
        </div>
    </section>
    <div id="loginPopup" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeLoginPopup()">&times;</span>
            <h2>Login or Sign Up</h2>
            <a href="#" class="login-btn">Login</a>
            <a href="#" class="signup-btn">Sign Up</a>
        </div>
    </div>
    <script src="//code.tidio.co/05cgzcbg95k7yztyodyurwiuxh1meibr.js" async>
         function showLoginPopup() {
            document.getElementById("loginPopup").style.display = "block";
        }
    
        function closeLoginPopup() {
            document.getElementById("loginPopup").style.display = "none";
        }
    
        window.onclick = function(event) {
            const modal = document.getElementById("loginPopup");
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2024 ResumeBuilder. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
