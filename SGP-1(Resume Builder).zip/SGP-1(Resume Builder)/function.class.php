<?php

class Functions {
    // Check if a user with the given full name or email already exists
    public function userExists($db, $full_name, $email) {
        $query = "SELECT * FROM users WHERE full_name = ? OR email_id = ?";
        $stmt = $db->connect()->prepare($query);
        $stmt->bind_param('ss', $full_name, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;  // Return true if user exists
    }

    // Create a new user in the database
    public function createUser($db, $full_name, $email, $hashed_password) {
        $query = "INSERT INTO users (full_name, email_id, password) VALUES (?, ?, ?)";
        $stmt = $db->connect()->prepare($query);
        $stmt->bind_param('sss', $full_name, $email, $hashed_password);
        return $stmt->execute();
    }

    // Get user data by full name (for login)
    public function getUserByUsername($db, $full_name) {
        $query = "SELECT * FROM users WHERE full_name = ?";
        $stmt = $db->connect()->prepare($query);
        $stmt->bind_param('s', $full_name);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();  // Return user data as an associative array
    }

    // Insert user details into the user_details table
    public function insertUserDetails($db, $user_id, $full_name, $email, $phone, $skills, $education, $experience, $interests, $projects, $introduction) {
        $query = "INSERT INTO user_details (user_id, full_name, email, phone, skills, education, experience, interests, projects, introduction) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->connect()->prepare($query);
        $stmt->bind_param('isssssssss', $user_id, $full_name, $email, $phone, $skills, $education, $experience, $interests, $projects, $introduction);
        return $stmt->execute();
    }

    // New function to retrieve user details for displaying on the resume page
    public function getUserDetails($db, $user_id) {
        $query = "SELECT * FROM user_details WHERE user_id = ?";
        $stmt = $db->connect()->prepare($query);
        $stmt->bind_param("i", $user_id); // bind user_id as an integer
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            return $result->fetch_assoc(); // Return data as an associative array
        } else {
            return false; // No data found
        }
    }
}

?>
