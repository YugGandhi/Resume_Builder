<?php
// Include database and functions classes
require_once 'database.class.php';
require_once 'function.class.php';

// Start session to handle login session
session_start();

// Create an instance of the function and database classes
$func = new Functions();
$db = new Database();

// Assuming you have the user_id stored in the session after login
$user_id = $_SESSION['user_id']; // Ensure this is set during login

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $skills = $_POST['skills'];
    $education = $_POST['education'];
    $experience = $_POST['experience'];
    $interests = $_POST['interests'];
    $projects = $_POST['projects'];
    $introduction = $_POST['introduction'];
    $template = $_POST['template']; // Capture selected template

    // Validate inputs (basic validation, can be expanded)
    if (empty($name) || empty($email) || empty($phone) || empty($skills) || empty($education) || empty($experience) || empty($interests) || empty($projects) || empty($introduction)) {
        echo "Please fill in all fields.";
        exit();
    }

    // Insert user details into the database
    if ($func->insertUserDetails($db, $user_id, $name, $email, $phone, $skills, $education, $experience, $interests, $projects, $introduction)) {
        // Redirect to the selected template page, passing user_id and template as query params
        header("Location: display_resume.php?template=$template&user_id=$user_id");
        exit(); // Ensure no further code is executed
    } else {
        echo "Error storing your details. Please try again.";
    }
} else {
    echo "Invalid request.";
}
?>
